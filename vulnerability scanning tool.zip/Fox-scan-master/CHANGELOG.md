# Changelog

## v0.0.1 (2016-09-05)

### BUG FIX
 - 修复不能实时刷新新数据问题

### FEATURE
 - 添加自动保存成功数据功能
 
 
## v0.0.2 (2016-09-06)

### FEATURE
 - 任务展示页点击LOG按钮显示扫描日志功能


## v0.0.3 (2016-09-14)

### BUGFIX
 - 修复windows路径报错问题
 - 修复需要ipdb第三方包的问题
 - 修复root密码为空报错问题 


## v0.1.0 (2016-10-04)

### BUGFIX
 - 修复爬虫网页同网站获取失败的问题
 - 修复停止任务无效的问题
 
### FEATURE
 - 将左侧task status连接到action/showtask
 - 添加HTTPS代理工具，支持https代理资源获取和检测
 
 


